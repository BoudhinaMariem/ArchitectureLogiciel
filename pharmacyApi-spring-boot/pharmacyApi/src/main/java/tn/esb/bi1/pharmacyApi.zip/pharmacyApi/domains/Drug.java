package tn.esb.bi1.pharmacyApi.domains;

import lombok.*;

import javax.persistence.*;
import java.time.LocalDate;

@Getter //genere tous les getters pour tous les attribus , au moment du rutime
@Setter
@NoArgsConstructor //genere un constructeur non paramétré
// @AllArgsConstructor //genere un constructeur avec tous les parametres
//@ToString //redéfinit la methode toString en retounant les valeurs de tous les attribus
//@ToString(exclude = {"stock","image"}) //retoune les valeurs de tous les attribus sauf celles de stock et image

@ToString(exclude = "image") //retourne tous sauf l'image
//@EqualsAndHashCode //permet de redefinit les deux methodes 'equals' et 'HashCode' en se basant sur tous les attribus pour comparer
//@EqualsAndHashCode(exclude = {"image","description","code"}) //compare par tous les attribus saut 'image' 'descriotion' et 'code'
@EqualsAndHashCode(onlyExplicitlyIncluded = true) //utilise uniquement les attribus annotés avec @--include dans la comparaison
@Entity   //permet de mentionner à l'ORM : object Relational Mapping que la classe Drug sera transformer en une table relationnel
public class Drug {
    @Id  //l'attribut 'code' est la clé primaire de la table Drug
    @GeneratedValue (strategy = GenerationType.IDENTITY) //permet de générer automatiquement les valeurs de la clé primaire
    private Long code;
    @EqualsAndHashCode.Include
    private String name;
    private double price;
    @EqualsAndHashCode.Include
    private LocalDate fabricationDate;
    private LocalDate expirationDate;
    private String description;
    private int stock;
    @Lob    //image est un tableau of byte avec une longueur plus long avec Lob
    private byte[] image;


}
