package tn.esb.bi1.pharmacyApi.domains;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;
import org.w3c.dom.Text;

import javax.persistence.Basic;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Address {
    @Getter
    @Setter
    @NoArgsConstructor
    @ToString

    @Id
    @GeneratedValue
    private Long id;
    private Integer num;
    @Basic
    private Text rue;
    private Integer code_postale;
}
