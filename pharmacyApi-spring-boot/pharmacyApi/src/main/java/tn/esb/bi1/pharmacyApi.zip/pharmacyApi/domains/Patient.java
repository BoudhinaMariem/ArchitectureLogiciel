package tn.esb.bi1.pharmacyApi.domains;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

public class Patient {
    @Getter
    @Setter
    @NoArgsConstructor
    @ToString

    private Long numSS;
    private String nom, prenom, adresse_mail;
    private Integer num_tel;

}
