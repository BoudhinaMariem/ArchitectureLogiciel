package tn.esb.bi1.pharmacyApi.enumerations;

public enum Specialitee {
    généraliste,
    orthopédiste,
    dermatologue,
    ophtamologue,
    neurologue,
    cardiologue,
    rhumatologue,
    ORL,
    autre
}
