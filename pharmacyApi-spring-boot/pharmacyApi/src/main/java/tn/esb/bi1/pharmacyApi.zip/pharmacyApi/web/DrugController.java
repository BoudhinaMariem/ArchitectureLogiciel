package tn.esb.bi1.pharmacyApi.web;

public class DrugController {
}
