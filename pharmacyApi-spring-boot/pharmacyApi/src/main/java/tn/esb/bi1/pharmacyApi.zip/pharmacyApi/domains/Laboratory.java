package tn.esb.bi1.pharmacyApi.domains;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.net.URL;

public class Laboratory {
    @Getter
    @Setter
    @NoArgsConstructor
    @ToString

    @Id
    @GeneratedValue
    private Long id;
    private String nom;
    private String adresse_mail;
    private Integer num_tel;
    private  url;
    private String NomResp;
}
