package tn.esb.bi1.pharmacyApi.domains;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.time.LocalDate;
import java.time.LocalTime;

public class Pharmacist {
    @Getter
    @Setter
    @NoArgsConstructor
    @ToString

    @Id
    @GeneratedValue
    private Long id;
    private String nom, prenom;
    private LocalDate DateNaissance;
    private LocalTime heureDebutTravail;
}
