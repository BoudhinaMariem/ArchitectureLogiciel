package tn.esb.bi1.pharmacyApi.domains;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import java.time.LocalDate;
import java.time.LocalTime;

public class Prescription {
    @Getter
    @Setter
    @NoArgsConstructor
    @ToString

    @Id
    @GeneratedValue
    private Long id;
    private LocalDate dateVisite;
    private LocalTime duree_traitement;
    private double montant;
    private LocalDate dateAchat;
}
