package tn.esb.bi1.pharmacyApi.repositories;

public interface DoctorRepository {
}
