package tn.esb.bi1.pharmacyApi.domains;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

public class Doctor {
    @Getter
    @Setter
    @NoArgsConstructor
    @ToString

    @Id
    @GeneratedValue
    private Long id;
    private String nom, prenom;
    private Integer num_tel;
    private String adresse_mail;


    //@Basic
    //private List<Doctor> specialitee ;
    @Enumerated
    private Specialitee spécialité;

    public Doctor(Specialitee spécialité) {
        this.spécialité = spécialité;
    }

}
